#ifndef _PLOT_H
#define _PLOT_H 1

int plot(float ***u, const int nx, const int ny, const int start);
int closeplot();

#endif
